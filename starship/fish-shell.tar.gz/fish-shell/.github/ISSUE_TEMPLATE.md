<!--
Please tell us which fish version you are using by executing the following:

  fish --version
  echo $version

Please tell us which operating system and terminal you are using. The output of `uname -a` and `echo $TERM` may be helpful in this regard although other commands might be relevant in your specific situation.

Please tell us if you tried fish without third-party customizations by executing this command and whether it affected the behavior you are reporting:

  sh -c 'env HOME=$(mktemp -d) fish'

Tell us how to reproduce the problem. Including an asciinema.org recording is useful for problems that involve the visual display of fish output such as its prompt.
-->

**YOUR TEXT HERE**
