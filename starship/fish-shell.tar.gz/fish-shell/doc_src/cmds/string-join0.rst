string-join0 - join strings with zero bytes
===========================================

.. include:: string-join.rst
   :start-line: 2
